import 'package:flutter/material.dart';

class DetailsPage extends StatelessWidget {
  const DetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mon appli',
      home: Center(
          child: Text("We are in!",
            style: TextStyle(fontSize:60 ),)
      ),
    );
  }
}