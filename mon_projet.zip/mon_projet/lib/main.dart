import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

/// Application principale
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CalculatorPage(),
    );
  }
}

/// Page de la calculatrice
class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String display = "0";
  String operation = "";
  double? first;
  String? operator;
  bool isNewInput = true;

  /// Gestion des boutons
  void onPress(String value) {
    setState(() {
      if (value == "C") {
        display = "0";
        operation = "";
        first = null;
        operator = null;
        isNewInput = true;
      }

      else if (value == "+/-") {
        if (display.startsWith("-")) {
          display = display.substring(1);
        } else {
          display = "-$display";
        }
      }

      else if (["+", "-", "×", "÷", "%"].contains(value)) {
        first = double.parse(display);
        operator = value;
        operation = "$display $value";
        isNewInput = true;
      }

      else if (value == "=") {
        if (first != null && operator != null) {
          double second = double.parse(display);
          double result = calculate(first!, second, operator!);
          display = result.toStringAsFixed(
              result % 1 == 0 ? 0 : 2);
          operation = "";
          first = null;
          operator = null;
          isNewInput = true;
        }
      }

      else if (value == ".") {
        if (!display.contains(".")) {
          display += ".";
        }
      }

      else {
        if (isNewInput) {
          display = value;
          isNewInput = false;
        } else {
          display += value;
        }
      }
    });
  }

  /// Calculs
  /// % = modulo classique
  double calculate(double a, double b, String op) {
    switch (op) {
      case "+":
        return a + b;
      case "-":
        return a - b;
      case "×":
        return a * b;
      case "÷":
        return b == 0 ? 0 : a / b;
      case "%":
        return a % b;
      default:
        return 0;
    }
  }

  /// Bouton rond standard
  Widget button(String text,
      {Color bg = const Color(0xFF3A3A3A),
        Color fg = Colors.white,
        int flex = 1}) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => onPress(text),
          child: Container(
            height: 75,
            decoration: BoxDecoration(
              color: bg,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                text,
                style: TextStyle(
                  fontSize: 26,
                  color: fg,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Bouton "=" vertical
  Widget equalButton() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => onPress("="),
          child: Container(
            height: 160,
            decoration: BoxDecoration(
              color: Colors.orange,
              borderRadius: BorderRadius.circular(40),
            ),
            child: const Center(
              child: Text(
                "=",
                style: TextStyle(
                  fontSize: 32,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      body: SafeArea(
        child: Column(
          children: [

            /// Affichage
            Expanded(
              flex: 2,
              child: Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.bottomRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      operation,
                      style: const TextStyle(
                        color: Colors.grey,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      display,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 56,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            /// Clavier
            Expanded(
              flex: 5,
              child: Column(
                children: [

                  Row(
                    children: [
                      button("C"),
                      button("%"),
                      button("÷", bg: Colors.orange),
                      button("×", bg: Colors.orange),
                    ],
                  ),

                  Row(
                    children: [
                      button("7"),
                      button("8"),
                      button("9"),
                      button("-", bg: Colors.orange),
                    ],
                  ),

                  Row(
                    children: [
                      button("4"),
                      button("5"),
                      button("6"),
                      button("+", bg: Colors.orange),
                    ],
                  ),

                  Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                button("1"),
                                button("2"),
                                button("3"),
                              ],
                            ),
                            Row(
                              children: [
                                button("+/-"),
                                button("0"),
                                button("."),
                              ],
                            ),
                          ],
                        ),
                      ),
                      equalButton(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
