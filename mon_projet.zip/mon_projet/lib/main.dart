// Import du package Material de Flutter
// Il contient tous les widgets nécessaires pour créer l’interface
import 'package:flutter/material.dart';

// Fonction principale : point d’entrée de l’application
void main() {
  // Lance l’application Flutter
  runApp(const MyApp());
}

/// Widget racine de l’application
/// StatelessWidget car il ne contient pas d’état modifiable
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // MaterialApp est le conteneur principal d’une application Flutter
    return const MaterialApp(
      // Supprime le bandeau "Debug"
      debugShowCheckedModeBanner: false,

      // Page principale de l’application
      home: CalculatorPage(),
    );
  }
}

/// Page principale de la calculatrice
/// StatefulWidget car l’interface change selon les actions de l’utilisateur
class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

/// Classe qui gère l’état de la calculatrice
class _CalculatorPageState extends State<CalculatorPage> {

  // Valeur affichée à l’écran
  String display = "0";

  // Opération affichée en petit (ex : 12 +)
  String operation = "";

  // Première valeur saisie
  double? first;

  // Opérateur sélectionné (+, -, ×, ÷, %)
  String? operator;

  // Indique si l’utilisateur commence une nouvelle saisie
  bool isNewInput = true;

  /// Méthode appelée à chaque appui sur un bouton
  void onPress(String value) {
    setState(() {

      // Bouton C : réinitialisation complète
      if (value == "C") {
        display = "0";
        operation = "";
        first = null;
        operator = null;
        isNewInput = true;
      }

      // Bouton +/- : change le signe du nombre
      else if (value == "+/-") {
        if (display.startsWith("-")) {
          display = display.substring(1);
        } else {
          display = "-$display";
        }
      }

      // Boutons opérateurs
      else if (["+", "-", "×", "÷", "%"].contains(value)) {
        first = double.parse(display); // Stocke la première valeur
        operator = value;              // Stocke l’opérateur
        operation = "$display $value"; // Affiche l’opération
        isNewInput = true;
      }

      // Bouton =
      else if (value == "=") {
        if (first != null && operator != null) {
          double second = double.parse(display); // Deuxième valeur
          double result = calculate(first!, second, operator!);

          // Affichage sans décimales inutiles
          display = result.toStringAsFixed(
              result % 1 == 0 ? 0 : 2);

          operation = "";
          first = null;
          operator = null;
          isNewInput = true;
        }
      }

      // Bouton décimal
      else if (value == ".") {
        if (!display.contains(".")) {
          display += ".";
        }
      }

      // Boutons chiffres
      else {
        if (isNewInput) {
          display = value;
          isNewInput = false;
        } else {
          display += value;
        }
      }
    });
  }

  /// Fonction de calcul
  /// Le bouton % est implémenté comme un modulo classique : a % b
  double calculate(double a, double b, String op) {
    switch (op) {
      case "+":
        return a + b;
      case "-":
        return a - b;
      case "×":
        return a * b;
      case "÷":
        return b == 0 ? 0 : a / b;
      case "%":
        return a % b;
      default:
        return 0;
    }
  }

  /// Widget bouton rond standard
  Widget button(
      String text, {
        Color bg = const Color(0xFF3A3A3A),
        Color fg = Colors.white,
        int flex = 1,
      }) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => onPress(text),
          child: Container(
            height: 75,
            decoration: BoxDecoration(
              color: bg,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                text,
                style: TextStyle(
                  fontSize: 26,
                  color: fg,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Bouton "=" vertical
  Widget equalButton() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: GestureDetector(
          onTap: () => onPress("="),
          child: Container(
            height: 160,
            decoration: BoxDecoration(
              color: Colors.orange,
              borderRadius: BorderRadius.circular(40),
            ),
            child: const Center(
              child: Text(
                "=",
                style: TextStyle(
                  fontSize: 32,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Construction de l’interface graphique
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      body: SafeArea(
        child: Column(
          children: [

            // Zone d’affichage
            Expanded(
              flex: 2,
              child: Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.bottomRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      operation,
                      style: const TextStyle(
                        color: Colors.grey,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      display,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 56,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Clavier de la calculatrice
            Expanded(
              flex: 5,
              child: Column(
                children: [

                  Row(
                    children: [
                      button("C"),
                      button("%"),
                      button("÷", bg: Colors.orange),
                      button("×", bg: Colors.orange),
                    ],
                  ),

                  Row(
                    children: [
                      button("7"),
                      button("8"),
                      button("9"),
                      button("-", bg: Colors.orange),
                    ],
                  ),

                  Row(
                    children: [
                      button("4"),
                      button("5"),
                      button("6"),
                      button("+", bg: Colors.orange),
                    ],
                  ),

                  Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                button("1"),
                                button("2"),
                                button("3"),
                              ],
                            ),
                            Row(
                              children: [
                                button("+/-"),
                                button("0"),
                                button("."),
                              ],
                            ),
                          ],
                        ),
                      ),
                      equalButton(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
